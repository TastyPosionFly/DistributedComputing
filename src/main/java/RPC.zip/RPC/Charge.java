package RPC;

public interface Charge {
    RPC.message charge(String data);
}
