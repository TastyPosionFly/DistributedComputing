package RPC.Server;

public class Main {
    public static void main(String[] args) {
        ChargeSever chargeSever = new ChargeSever();
        chargeSever.start();
    }
}
