package GameSpringFramework.item;

public interface Item {
    void use();
}
