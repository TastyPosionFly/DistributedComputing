package GameSpringFramework;

public class AspectProgram {
    public void beforeFight(){
        System.out.println("Before Fight");
    }
    public void afterFight(){
        System.out.println("After Fight");
    }
}
